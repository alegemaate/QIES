View using
cat 'filename'
for full colour experience!

initial.txt 
============
This is the first test run. Most things did not work.
We removed test cases which only failed because of a newline issue and
replaced them with successes.

fixed_expected.txt
==================
This run includes the tests after all test cases were fixed. The code 
was not modified at this stage.

fixed_code.txt
==============
This is the final run. All code was fixed and tests all succeed.