/*
 * Configuration
 * Stores static configuration data
 * Spice Tests
 * 15/10/2018
 */

public class Configuration {
	// Location of txn summary file
	public static String tsfPath = "";
	
	// Location of valid services file
	public static String vsfPath = "";
} // end Configuration class
